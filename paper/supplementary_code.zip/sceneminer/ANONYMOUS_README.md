# SceneMiner: anonymous supplementary code

Code, benchmark definitions, anonymised human labels and every result file behind the
tables of the submission.

## Contents

| path | what |
|---|---|
| `src/scene_mining/filter/` | SceneMiner (`sceneminer_v2_6.py`, the final model) and its predecessors; the cached index (`fast_index.py`) |
| `scripts/` | training, evaluation, baselines, table and figure generators |
| `benchmark_cvpr/` | splits, the 390-query suite, the 40 Stratum-5 queries, the pre-registered 36-query BDD100K holdout, the 160-scene second-rater subset |
| `benchmark_cvpr/human_rater1_600.json` | rater 1, 600 scenes (550 after unsure/skip), four degradation attributes |
| `benchmark_cvpr/human_rater2_160.json` | rater 2, 160 scenes |
| `results/cvpr/*.json` | every number in the paper; `scripts/verify_paper_numbers.py` maps each claim to a JSON path |

## Environment

Python 3.11, PyTorch 2, `transformers`, `pypdf`, `numpy`, `matplotlib`.
Machine-specific locations are read from environment variables (`scripts/paths.py`):

| variable | default |
|---|---|
| `SCENEMINER_DATA_ROOT` | `data` (holds `external_adverse/bdd100k`, `external_adverse/bdd100k_holdout`) |
| `QWEN_VL` | `Qwen/Qwen2.5-VL-3B-Instruct` |
| `BLIP2` | `Salesforce/blip2-opt-2.7b` |
| `SIGLIP2_SO400M` | `google/siglip2-so400m-patch14-384` |
| `PY` (shell scripts) | `python` |

Datasets are not redistributed: nuScenes, Waymo Open Dataset and BDD100K must be
obtained under their own licences. Cached Stage-1 features and checkpoints are not
included for size.

## Reproducing

```
export PYTHONPATH=src
python scripts/train_sceneminer_v26.py --work-dir work_dirs/sceneminer_v26/s0 --seed 0   # x5 seeds
SM_FINAL=v26 python scripts/eval_related_work_baselines.py      # Table 2
SM_FINAL=v26 python scripts/incorporate_rater2.py               # second rater
python scripts/eval_per_query_vlm_reranker.py --part eval       # per-query VLM reranker
python scripts/make_main_tables.py && python scripts/make_tab_master.py   # tables from results/cvpr
```

The table generators read only `results/cvpr/*.json`, so all tables can be rebuilt
without data or GPUs.
