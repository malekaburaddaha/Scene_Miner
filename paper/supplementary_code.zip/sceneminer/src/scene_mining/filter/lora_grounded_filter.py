#!/usr/bin/env python3
"""LoRA-Grounded Unified Filter — v2 (post-diagnostic architecture repair).

Fixes applied after `results/diagnostic_investigation.md`:

  [P1] SCALAR CHANNEL REPAIR. The risk adapter used LayerNorm on a width-1
       input, which is identically zero for every input, so the risk token
       was a bit-identical constant across all 1,508 scenes while absorbing
       ~31.5% of cross-attention mass. Scalar channels now use fixed
       dataset-statistics standardisation (mu, sigma) — see ModalityAdapter.

  [P2] DE-SATURATED SCORING. Previously the score was an unbounded
       bilinear+MLP sum divided by a LEARNED temperature that drifted below
       1 and sharpened an already 213-unit score span, driving the listwise
       softmax to an effective support of ~1 scene out of 1,508. Now:
         * query and fused vectors are L2-normalised before scoring
         * both score terms are bounded to [-1, 1] (cosine / tanh)
         * temperature is a FIXED, lower-bounded buffer (not learned)
       so the logit range is bounded by 2/tau by construction.

  [P2] CAPACITY. LoRA rank raised to r=64 / alpha=128 on q/k/v.

  `score(..., return_fused=True)` also returns the PRE-normalisation fused
  vector, which the trainer feeds to the VICReg variance/covariance terms
  (the fused space had collapsed to effective rank 3.2-4.4 of 256).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from scene_mining.filter.unified_filter import (FiLM, ModalityAdapter,
                                                ScalarStandardize,
                                                count_parameters)

# Fixed dataset statistics for the scalar risk channel (features_overnight).
RISK_MU, RISK_SIGMA = 0.417797, 0.081112


class QwenVisualEncoder(nn.Module):
    """Qwen2.5-VL-3B with LoRA adapters; one pooled visual vector per image.
    Only lora_* parameters require grad."""

    PROMPT = "Describe the driving conditions."
    IMG_MAX_SIDE = 448   # overridable per-instance for throughput

    def __init__(self, model_path: str, lora_r: int = 64,
                 lora_alpha: int = 128, device: str = "cuda",
                 img_max_side: int | None = None) -> None:
        super().__init__()
        if img_max_side:
            self.IMG_MAX_SIDE = int(img_max_side)
        from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
        from peft import LoraConfig, get_peft_model
        self.proc = AutoProcessor.from_pretrained(model_path)
        base = Qwen2_5_VLForConditionalGeneration.from_pretrained(
            model_path, torch_dtype=torch.bfloat16)
        for p in base.parameters():
            p.requires_grad_(False)
        cfg = LoraConfig(r=lora_r, lora_alpha=lora_alpha,
                         target_modules=["q_proj", "k_proj", "v_proj"],
                         lora_dropout=0.05, bias="none",
                         task_type="CAUSAL_LM")
        self.model = get_peft_model(base, cfg)
        self.model.gradient_checkpointing_enable()
        self.model.enable_input_require_grads()
        self._d = base.config.text_config.hidden_size
        self.device_str = device

    @property
    def d_model(self) -> int:
        return self._d

    def encode(self, pil_images: list) -> torch.Tensor:
        def shrink(im):
            w, h = im.size
            if max(w, h) <= self.IMG_MAX_SIDE:
                return im
            sc = self.IMG_MAX_SIDE / max(w, h)
            return im.resize((int(w * sc), int(h * sc)))
        pil_images = [shrink(im) for im in pil_images]
        msgs = [[{"role": "user", "content": [
            {"type": "image", "image": im},
            {"type": "text", "text": self.PROMPT}]}] for im in pil_images]
        texts = [self.proc.apply_chat_template(
            m, tokenize=False, add_generation_prompt=True) for m in msgs]
        inp = self.proc(text=texts, images=pil_images, padding=True,
                        return_tensors="pt").to(self.model.device)
        # logits_to_keep=1: never materialise the (B,L,150k) lm_head output.
        out = self.model(**inp, output_hidden_states=True, logits_to_keep=1)
        h = out.hidden_states[-1]
        img_tok_id = self.model.config.image_token_id
        mask = (inp["input_ids"] == img_tok_id).unsqueeze(-1)
        pooled = (h * mask).sum(1) / mask.sum(1).clamp(min=1)
        return pooled.float()


class LoRAGroundedFilter(nn.Module):
    """score(query, scene) with a live LoRA-adapted visual token."""

    N_TOKENS = 4          # embedding / tags / risk / LoRA-visual

    def __init__(self, visual_encoder: QwenVisualEncoder,
                 d_clip: int = 512, d_embed: int = 256, n_tags: int = 20,
                 d_model: int = 256, n_heads: int = 4,
                 n_fusion_layers: int = 2, bilinear_rank: int = 64,
                 dropout: float = 0.1, tau: float = 0.4,
                 tau_min: float = 0.1,
                 risk_stats: tuple[float, float] = (RISK_MU, RISK_SIGMA),
                 legacy_scoring: bool = False,
                 legacy_scalar: bool = False,
                 force_layernorm1d: bool = False,
                 unbounded_tau: bool = False,
                 clip_logit_scale: bool = False,
                 pool: str = "xattn") -> None:
        super().__init__()
        self.legacy_scoring = legacy_scoring
        self.unbounded_tau = unbounded_tau
        self.clip_logit_scale = clip_logit_scale
        if clip_logit_scale:
            # CLIP parameterisation: a MULTIPLICATIVE log-scale initialised at
            # 1/0.07 = 14.29 and free to grow, applied to UNNORMALISED
            # projections. This is the construction that can actually produce a
            # 200+ unit score span; dividing by a learned tau cannot, because
            # tau drifts upward (measured: 1.070 at 3k, 1.249 at 12k steps).
            import math
            self.logit_scale = nn.Parameter(torch.tensor(math.log(1.0 / 0.07)))
        # [R3 ablation] pooling of the FiLM-conditioned modality tokens into
        # the fused vector. "xattn" is the query-conditioned cross-attention
        # of the main method; "mean" replaces it with an unweighted mean, so
        # conditioning survives only through FiLM. self.fusion is always
        # built so checkpoints stay state-dict compatible across variants.
        assert pool in ("xattn", "mean"), pool
        self.pool = pool
        self.visual = visual_encoder
        self.adapt_embed = ModalityAdapter(d_embed, d_model)
        self.adapt_tags = ModalityAdapter(n_tags, d_model)
        # [P1] scalar channel: fixed standardisation, never LayerNorm
        # legacy_scalar reproduces the ORIGINAL bug (LayerNorm on width-1),
        # used only to reproduce the pre-repair ablation baseline.
        # force_layernorm1d = the TRUE original defect (see ModalityAdapter).
        # legacy_scalar alone only swaps (mu,sigma) -> it does NOT kill the channel.
        if force_layernorm1d:
            self.adapt_risk = ModalityAdapter(1, d_model, force_layernorm1d=True)
        elif legacy_scalar:
            self.adapt_risk = ModalityAdapter(1, d_model)
        else:
            self.adapt_risk = ModalityAdapter(1, d_model, scalar_stats=risk_stats)
        self.adapt_visual = ModalityAdapter(visual_encoder.d_model, d_model)
        self.adapt_query = ModalityAdapter(d_clip, d_model)
        self.type_embed = nn.Parameter(torch.randn(self.N_TOKENS, d_model) * 0.02)
        self.film = FiLM(d_model, d_model, self.N_TOKENS)
        layer = nn.TransformerDecoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=4 * d_model,
            dropout=dropout, batch_first=True, norm_first=True)
        self.fusion = nn.TransformerDecoder(layer, num_layers=n_fusion_layers)
        self.bil_q = nn.Linear(d_model, bilinear_rank, bias=False)
        self.bil_c = nn.Linear(d_model, bilinear_rank, bias=False)
        self.mlp = nn.Sequential(
            nn.LayerNorm(4 * d_model),
            nn.Linear(4 * d_model, d_model), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(d_model, 1))
        if legacy_scoring:
            # pre-repair: unbounded score / LEARNED temperature
            self.log_tau = nn.Parameter(torch.zeros(()))
            self.register_buffer("tau", torch.tensor(float(tau)))
        else:
            # [P2] FIXED, lower-bounded temperature (buffer, NOT a parameter)
            self.register_buffer("tau",
                                 torch.tensor(max(float(tau), float(tau_min))))

    # ------------------------------------------------------------------
    def scene_tokens(self, e, t, r, v):
        toks = torch.stack([
            self.adapt_embed(e), self.adapt_tags(t),
            self.adapt_risk(r), self.adapt_visual(v)], dim=1)
        return toks + self.type_embed.unsqueeze(0)

    def score(self, q_clip, e, t, r, v, return_fused: bool = False):
        """Bounded, temperature-controlled score.

        s = (cos_bilinear + tanh_mlp) / tau  in  [-2/tau, +2/tau].
        """
        q = self.adapt_query(q_clip)
        toks = self.film(self.scene_tokens(e, t, r, v), q)
        if self.pool == "mean":
            fused_raw = toks.mean(dim=1)
        else:
            fused_raw = self.fusion(tgt=q.unsqueeze(1), memory=toks)[:, 0]

        if self.legacy_scoring:
            s_bil = (self.bil_q(q) * self.bil_c(fused_raw)).sum(-1)
            s_mlp = self.mlp(torch.cat(
                [q, fused_raw, q * fused_raw,
                 (q - fused_raw).abs()], dim=-1)).squeeze(-1)
            # unbounded_tau removes the 1e-2 floor, so a learned temperature is
            # free to collapse toward zero and saturate the listwise softmax -
            # the predecessor defect Sec. 4.2 describes.
            if self.clip_logit_scale:
                s = self.logit_scale.exp() * (s_bil + s_mlp)
            else:
                _t = self.log_tau.exp()
                s = (s_bil + s_mlp) / (_t if self.unbounded_tau else _t.clamp(min=1e-2))
        else:
            qn = F.normalize(q, dim=-1)
            cn = F.normalize(fused_raw, dim=-1)
            s_bil = F.cosine_similarity(self.bil_q(qn), self.bil_c(cn), dim=-1)
            s_mlp = torch.tanh(self.mlp(
                torch.cat([qn, cn, qn * cn, (qn - cn).abs()], dim=-1)).squeeze(-1))
            s = (s_bil + s_mlp) / self.tau
        return (s, fused_raw) if return_fused else s

    def trainable_parameters(self):
        return [p for p in self.parameters() if p.requires_grad]


# ── VICReg terms [P2] ─────────────────────────────────────────────────
def vicreg_terms(z: torch.Tensor, w_var: float = 1.0, w_cov: float = 0.04,
                 eps: float = 1e-4):
    """Variance hinge max(0, 1 - std_j) + off-diagonal covariance penalty,
    applied to the PRE-normalisation fused batch to spread the collapsed cap."""
    zc = z - z.mean(0, keepdim=True)
    std = torch.sqrt(zc.var(0, unbiased=False) + eps)
    v = F.relu(1.0 - std).mean()
    n, d = zc.shape
    cov = (zc.T @ zc) / max(n - 1, 1)
    off = cov - torch.diag_embed(torch.diagonal(cov))
    c = off.pow(2).sum() / d
    return w_var * v + w_cov * c, float(v.detach()), float(c.detach())


if __name__ == "__main__":
    # scalar-repair regression test (no GPU needed)
    a = ModalityAdapter(1, 8, scalar_stats=(RISK_MU, RISK_SIGMA))
    x = torch.tensor([[0.20], [0.42], [0.60]])
    y = a(x)
    print("distinct risk outputs:", len(torch.unique(y, dim=0)), "of 3")
    assert len(torch.unique(y, dim=0)) == 3, "risk channel still collapsed!"
    print("OK — scalar channel passes variance")
